function run_install_check(workspace)
control = fullfile(workspace, 'control');
restoredefaultpath;
addpath(control);
fprintf('MATLAB_RELEASE=%s\n', version('-release'));

% Reproduce the actual GitHub sparse checkout failure without writing paths.
cd(fullfile(workspace, 'remote-bds'));
failed_as_expected = false;
try
    setup;
catch exception
    assert(strcmp(exception.identifier, 'bds:PathNotExist'));
    assert(contains(exception.message, fullfile(pwd, 'tests')));
    fprintf('OLD_SPARSE_SETUP_EXPECTED_FAILURE %s\n', exception.identifier);
    failed_as_expected = true;
end
assert(failed_as_expected);

outputs = cell(2, 2);
layouts = {'candidate-bds', 'candidate-source'};
for layout = 1:2
    restoredefaultpath;
    addpath(control);
    folder = fullfile(workspace, layouts{layout});
    cd(folder);
    clear setup bds bds_paper_options
    message = evalc('setup');
    assert(strcmp(which('bds'), fullfile(folder, 'src', 'bds.m')));
    assert(contains(help('bds'), 'DFOS2024.pdf'));
    assert(contains(path, fullfile(folder, 'examples')));
    if layout == 1
        assert(~isfolder('tests') && ~isfolder('research') && ~isfolder('docs') && ~isfolder('.github'));
        assert(isempty(which('bds_paper_options')));
        assert(isempty(which('testbds')));
        assert(~contains(message, 'testbds'));
    else
        assert(strcmp(which('bds_paper_options'), fullfile(folder, 'tests', 'bds_paper_options.m')));
        assert(strcmp(which('testbds'), fullfile(folder, 'tests', 'testbds.m')));
        assert(contains(message, 'testbds'));
    end
    fprintf('SETUP_PATHS_OK %s\n', layouts{layout});
    for k = 1:2
        x0 = [1; 2; 3];
        options = struct('seed', 12345, 'output_xhist', true, 'output_alpha_hist', true, ...
            'output_grad_hist', true, 'output_block_hist', true, ...
            'use_estimated_gradient_stop', logical(k-1));
        rng(12345, 'twister');
        result = struct();
        [result.x, result.f, result.exitflag, result.output] = bds(@(x) sum(x.^2), x0, options);
        assert(isfinite(result.f) && result.f < sum(x0.^2));
        outputs{layout,k} = result;
    end
end
assert(isequaln(outputs(1,:), outputs(2,:)));
fprintf('SPARSE_FULL_SOLVER_EQUALITY_OK cases=2\n');

% The complete checkout must retain its existing regression entry point.
run_bds_regression_suite();
save(fullfile(workspace, 'results', 'solver_outputs.mat'), 'outputs');
fprintf('SPARSE_INSTALL_CHECK_OK\n');
end

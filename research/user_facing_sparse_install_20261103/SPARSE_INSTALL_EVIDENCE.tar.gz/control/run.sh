#!/usr/bin/env bash
set -u
workspace=$(cd "$(dirname "$0")/.." && pwd)
test ! -e "$workspace/results/install.status" || exit 2
printf 'started utc=%s\n' "$(date -u +%FT%TZ)" > "$workspace/results/install.status"
matlab -singleCompThread -batch "addpath('$workspace/control'); run_install_check('$workspace')" > "$workspace/logs/install.log" 2>&1 </dev/null
code=$?
printf 'exit_code=%s utc=%s\n' "$code" "$(date -u +%FT%TZ)" > "$workspace/results/install.status"
exit "$code"

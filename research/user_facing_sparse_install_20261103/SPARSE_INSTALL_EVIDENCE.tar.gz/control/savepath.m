function status = savepath(varargin)
% Keep installation paths session-local during isolated server verification.
status = 0;
end

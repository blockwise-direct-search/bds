import hashlib
import json
from pathlib import Path
import re
import sys

root = Path(sys.argv[1])
original_manifest = json.loads((root / 'SOURCE_MANIFEST.json').read_text())
manifest = json.loads((root / 'SNAPSHOT_MANIFEST.json').read_text())
metadata_omitted = sorted(set(original_manifest) - set(manifest))
assert all(Path(name).name.startswith('._') for name in metadata_omitted)
assert all(original_manifest[name] == digest for name, digest in manifest.items())
for name, digest in manifest.items():
    assert hashlib.sha256((root / 'candidate-source' / name).read_bytes()).hexdigest() == digest, name
clones = json.loads((root / 'CLONE_REPORT.json').read_text())
for layout in ('remote-bds', 'candidate-bds'):
    for name, digest in clones[layout]['hashes'].items():
        assert hashlib.sha256((root / layout / name).read_bytes()).hexdigest() == digest, (layout, name)
status = (root / 'results/install.status').read_text().strip()
assert status.startswith('exit_code=0 '), status
log = (root / 'logs/install.log').read_text()
for marker in ('OLD_SPARSE_SETUP_EXPECTED_FAILURE bds:PathNotExist',
               'SETUP_PATHS_OK candidate-bds', 'SETUP_PATHS_OK candidate-source',
               'SPARSE_FULL_SOLVER_EQUALITY_OK cases=2', 'BDS_REGRESSION_SUITE_OK',
               'SPARSE_INSTALL_CHECK_OK',
               'GRADIENT_STOPPING_THRESHOLD_OK behavior=120 shared=1 changed=1 disabled=1'):
    assert marker in log, marker
assert len(re.findall(r'\[acceleration-off-Algorithm-[^\]]+\] case \d+/270 passed', log)) == 1350
assert clones['remote-bds']['paper_helper_present']
assert not clones['candidate-bds']['paper_helper_present']
print(json.dumps({'status': 'verified', 'matlab_status': status,
                  'remote_commit': clones['remote-bds']['commit'],
                  'remote_still_has_old_paper_helper': True,
                  'candidate_visible_files': len(clones['candidate-bds']['files']),
                  'candidate_visible_paths': clones['candidate-bds']['files'],
                  'candidate_has_paper_helper': False,
                  'old_sparse_setup_failure_reproduced': True,
                  'new_sparse_and_full_setup_passed': True,
                  'full_solver_output_pairs': 2,
                  'regression_acceleration_off_cases': 1350, 'gradient_boundary_cases': 120,
                  'source_snapshot_files': len(manifest), 'macos_metadata_omitted_by_tar': metadata_omitted,
                  'user_repository_committed_or_pushed': False,
                  'limits': ['Session-local savepath shim; persistent MATLAB path permissions not tested.',
                             'Sparse checkout is not access control.',
                             'Candidate changes are not yet on GitHub.']}, indent=2))

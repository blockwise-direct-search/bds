function run_readme_check(workspace, stage)
restoredefaultpath;
addpath(fullfile(workspace, 'control'));
root = fullfile(workspace, 'candidate');
fprintf('MATLAB_RELEASE=%s STAGE=%s\n', version('-release'), stage);
fprintf('TIME=%s\n', string(datetime('now', 'TimeZone', 'Asia/Shanghai')));
if strcmp(stage, 'gradient')
    cd(fullfile(root, 'src', 'private'));
    assert(strcmp(which('test_gradient'), fullfile(pwd, 'test_gradient.m')));
    test_gradient();
else
    cd(fullfile(workspace, 'optiprofiler'));
    setup(struct('install_matcutest', false));
    cd(root);
    setup;
    addpath(fullfile(root, 'tests', 'competitors'));
    cd(fullfile(root, 'tests'));
    assert(strcmp(which('bds'), fullfile(root, 'src', 'bds.m')));
    parameters.parallel = strcmp(stage, 'simplified_parallel');
    if parameters.parallel
        cluster = parcluster('local');
        storage = fullfile(workspace, 'parallel_jobs');
        if ~isfolder(storage), mkdir(storage); end
        cluster.JobStorageLocation = storage;
        pool = parpool(cluster, 8);
        cleanup = onCleanup(@() delete(pool));
    end
    verify_simplified_bds(parameters);
end
fprintf('README_CHECK_OK %s %s\n', version('-release'), stage);
end

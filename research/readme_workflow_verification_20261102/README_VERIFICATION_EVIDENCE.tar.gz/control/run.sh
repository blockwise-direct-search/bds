#!/usr/bin/env bash
set -u
workspace=$(cd "$(dirname "$0")/.." && pwd)
release=$1
stage=$2
label="${release}_${stage}${3:-}"
test ! -e "$workspace/results/$label.status" || exit 2
printf 'started utc=%s\n' "$(date -u +%FT%TZ)" > "$workspace/results/$label.status"
"/usr/local/MATLAB/$release/bin/matlab" -singleCompThread -batch "addpath('$workspace/control'); run_readme_check('$workspace', '$stage')" > "$workspace/logs/$label.log" 2>&1 </dev/null
result=$?
printf 'exit_code=%s utc=%s\n' "$result" "$(date -u +%FT%TZ)" > "$workspace/results/$label.status"
exit "$result"

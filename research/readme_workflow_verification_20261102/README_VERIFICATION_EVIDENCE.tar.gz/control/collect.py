"""Audit the unchanged BDS snapshot and summarize the README checks."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

root = Path(sys.argv[1])
manifest = json.loads((root / 'SYNC_MANIFEST.json').read_text())
for name, digest in manifest.items():
    assert hashlib.sha256((root / 'candidate' / name).read_bytes()).hexdigest() == digest, name
stages = ['R2024b_gradient_retry1', 'R2025a_gradient_retry1', 'R2026a_gradient',
          'R2024b_simplified_sequential_retry1', 'R2024b_simplified_parallel']
results = {}
for stage in stages:
    status = (root / 'results' / (stage + '.status')).read_text().strip()
    log = (root / 'logs' / (stage + '.log')).read_text()
    if stage == 'R2024b_simplified_sequential_retry1':
        assert status.startswith('exit_code=143 '), (stage, status)
    else:
        assert status.startswith('exit_code=0 '), (stage, status)
    assert 'README_CHECK_OK' in log, stage
    results[stage] = {'status': status, 'assertions_passed': True,
                      'clean_exit': status.startswith('exit_code=0 ')}
    if 'simplified' in stage:
        cases = re.findall(r'^(\d+)\((\d+)\)\. (\S+)\s*$', log, re.M)
        assert len(cases) == 860, (stage, len(cases))
        assert {(int(p), int(r)) for p, r, _ in cases} == {
            (p, r) for p in range(1, 173) for r in range(1, 6)}
        results[stage]['problems'] = 172
        results[stage]['cases'] = len(cases)
        results[stage]['weekly_seeds'] = sorted(set(re.findall(r'YW = (\d+)', log)))
        results[stage]['comparison'] = 'Unchanged iseqiv_simplified at prec=0: x, f, exitflag, funcCount; no full-history assertion.'
    else:
        results[stage]['assertion'] = re.findall(r'Test passed!.*', log)
        assert len(results[stage]['assertion']) == 1
prior = {p.stem: p.read_text().strip() for p in (root / 'results').glob('*.status')
         if p.stem not in stages}
s2mpj = root / 'optiprofiler/matlab/optiprofiler/problem_libs/s2mpj'
revision = subprocess.check_output(['git', '-C', str(s2mpj), 'rev-parse', 'HEAD'], text=True).strip()
report = {
    'status': 'all_assertions_passed_with_serial_shutdown_issue', 'server_workspace': str(root),
    'bds_base_commit': '67014737eaa9dbe47f7eb40e6d6829e27617277e',
    'bds_worktree': 'Current uncommitted dual-gradient-criterion snapshot; all 222 synchronized files unchanged.',
    'optiprofiler_commit': '5a19e88cc34f9b8925e111934a6b12011422fcdb',
    's2mpj_commit': revision, 'results': results, 'earlier_attempts': prior,
    'environment_notes': [
        'Initial R2024b/R2025a gradient assertions passed but MATLAB aborted on exit (137); unchanged retries exited 0.',
        'Initial simplified setup failed because MATLAB subprocess Git had a libcurl/libssh2 symbol conflict. Its stuck process was terminated. The dependency was cloned in the ordinary shell and unchanged tests rerun.',
        'R2024b simplified sequential completed all 860 checks and printed README_CHECK_OK at 15:22:45 UTC. The process remained in futex wait with no new log output until 15:25:30 UTC; its exact PID 369555 was terminated with SIGTERM, yielding exit 143. This is NOT a clean process pass. Underlying shutdown cause is unresolved.',
        'An isolated savepath shim made setup session-only; no shared pathdef/startup changes. Parallel execution used eight workers.',
    ],
    'limits': [
        'Linux server execution, not an actual GitHub Actions run.',
        'No Windows/macOS or unavailable R2023b/R2024a validation.',
        'Gradient estimation is not the final gradient-stopping-criterion test; that has a separate completed regression report.',
        'No external solver benchmark, solver/test/workflow edits, commit or push.',
    ],
    'source_manifest_sha256': hashlib.sha256((root / 'SYNC_MANIFEST.json').read_bytes()).hexdigest(),
}
print(json.dumps(report, indent=2))

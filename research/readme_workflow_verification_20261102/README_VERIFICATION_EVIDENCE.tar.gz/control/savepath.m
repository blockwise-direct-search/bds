function status = savepath(varargin)
% Session-only installation in an isolated verification workspace.
% Do not modify the shared MATLAB pathdef.m or trigger startup.m fallbacks.
status = 0;
end

# README workflow verification, 2026-11-02

Run the current uncommitted BDS snapshot without editing solver/tests/workflows.
Targets: gradient_test.yml and verify_simplified_bds.yml only.

1. Check local files against the previous verified synchronization manifest; copy that snapshot to a new isolated server directory.
2. Export the exact OptiProfiler commit 5a19e88cc34f9b8925e111934a6b12011422fcdb. Run its setup with install_matcutest=false, as the workflow does; record the S2MPJ revision actually installed.
3. Run test_gradient() on available MATLAB releases. Run the unchanged verify_simplified_bds with parallel=false and true on R2024b, leaving problem selection, run count and precision at their workflow defaults.
4. Setup paths are session-only: an isolated savepath shim prevents writes to shared MATLAB pathdef/startup. Parallel worker count is eight; no case selection or assertion is modified.
5. Preserve logs and actual exit codes, audit source hashes, download evidence. Report failures without changing code. A Linux server cannot validate Windows/macOS or unavailable MATLAB releases.

Initial environment observations: R2024b and R2025a gradient assertions passed but MATLAB aborted on exit (137); R2026a passed and exited 0. The initial R2024b simplified run could not install S2MPJ: MATLAB's Git subprocess had a libcurl/libssh2 symbol conflict. Install the same public dependency from the ordinary shell, then rerun unchanged test entry points with separate attempt labels. Do not count aborted processes as clean passes.

Final result: all three gradient runs passed with exit 0 after unchanged retries where needed. R2024b simplified parallel passed all 860 cases and exited 0. Sequential passed all 860 cases and printed success at 15:22:45 UTC, but remained waiting during shutdown; after read-only process inspection, its exact process was terminated at 15:25:30 UTC (exit 143). Report assertion success separately from the unresolved shutdown issue. No solver/test/workflow changes or full additional rerun to conceal the exit issue.

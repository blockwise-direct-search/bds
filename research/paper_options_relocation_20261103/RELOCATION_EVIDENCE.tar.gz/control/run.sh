#!/usr/bin/env bash
set -u
workspace=$(cd "$(dirname "$0")/.." && pwd)
stage=$1
test ! -e "$workspace/results/$stage.status" || exit 2
printf 'started utc=%s\n' "$(date -u +%FT%TZ)" > "$workspace/results/$stage.status"
matlab -singleCompThread -batch "addpath('$workspace/control'); run_relocation_check('$workspace', '$stage')" > "$workspace/logs/$stage.log" 2>&1 </dev/null
code=$?
printf 'exit_code=%s utc=%s\n' "$code" "$(date -u +%FT%TZ)" > "$workspace/results/$stage.status"
exit "$code"

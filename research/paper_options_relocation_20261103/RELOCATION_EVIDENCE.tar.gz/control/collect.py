import hashlib
import json
from pathlib import Path
import re
import sys

root = Path(sys.argv[1])
manifest = json.loads((root / 'SYNC_MANIFEST.json').read_text())
for name, digest in manifest.items():
    assert hashlib.sha256((root / 'candidate' / name).read_bytes()).hexdigest() == digest, name
assert not (root / 'candidate/examples/bds_paper_options.m').exists()
helper = root / 'candidate/tests/bds_paper_options.m'
before = Path('/home/lhtian97/Work/bds_dual_gradient_production_20261102/candidate/examples/bds_paper_options.m')
assert helper.read_bytes() == before.read_bytes()
statuses = {}
for stage in ('smoke', 'regression'):
    status = (root / 'results' / (stage + '.status')).read_text().strip()
    assert status.startswith('exit_code=0 '), status
    log = (root / 'logs' / (stage + '.log')).read_text()
    assert 'RELOCATION_STAGE_OK ' + stage in log
    statuses[stage] = status
regression = (root / 'logs/regression.log').read_text()
assert len(re.findall(r'\[acceleration-off-Algorithm-[^\]]+\] case \d+/270 passed', regression)) == 1350
assert 'GRADIENT_STOPPING_THRESHOLD_OK behavior=120 shared=1 changed=1 disabled=1' in regression
assert 'BDS_REGRESSION_SUITE_OK' in regression
assert 'PAPER_OPTIONS_RELOCATION_OK configurations=12 solver_pairs=12 invalid=1' in (root / 'logs/smoke.log').read_text()
print(json.dumps({'status': 'verified', 'stages': statuses, 'synced_files': len(manifest),
                  'helper_sha256': hashlib.sha256(helper.read_bytes()).hexdigest(),
                  'helper_identical_to_before_move': True, 'configuration_pairs': 12,
                  'full_solver_output_pairs': 12, 'invalid_configuration_checks': 1,
                  'regression_acceleration_off_cases': 1350, 'gradient_boundary_cases': 120,
                  'benchmark_run': False, 'paper_manuscript_modified': False}, indent=2))

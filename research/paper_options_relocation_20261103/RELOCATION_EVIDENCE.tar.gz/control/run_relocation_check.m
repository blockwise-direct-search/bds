function run_relocation_check(workspace, stage)
restoredefaultpath;
root = fullfile(workspace, 'candidate');
addpath(fullfile(root, 'src'));
if strcmp(stage, 'smoke')
    before = '/home/lhtian97/Work/bds_dual_gradient_production_20261102/candidate/examples';
    addpath(before);
    assert(strcmp(which('bds_paper_options'), fullfile(before, 'bds_paper_options.m')));
    configurations = {'internal', 'mp'; 'internal', 'noacc'; 'internal', 'ds'; 'external', 'mp'};
    expected = cell(3, 4);
    options_before = cell(3, 4);
    dimensions = [1, 3, 7];
    for i = 1:3
        x0 = (1:dimensions(i))' / 3;
        for j = 1:4
            options_before{i,j} = bds_paper_options(x0, configurations{j,1}, configurations{j,2});
            expected{i,j} = run_solver(x0, options_before{i,j});
        end
    end
    rmpath(before);
    clear bds_paper_options
    addpath(fullfile(root, 'tests'));
    assert(strcmp(which('bds_paper_options'), fullfile(root, 'tests', 'bds_paper_options.m')));
    assert(~isfile(fullfile(root, 'examples', 'bds_paper_options.m')));
    for i = 1:3
        x0 = (1:dimensions(i))' / 3;
        for j = 1:4
            actual = bds_paper_options(x0, configurations{j,1}, configurations{j,2});
            previous = options_before{i,j};
            assert(strcmp(func2str(actual.forcing_function), func2str(previous.forcing_function)));
            assert(isequaln(rmfield(actual, 'forcing_function'), rmfield(previous, 'forcing_function')));
            assert(isequaln(run_solver(x0, actual), expected{i,j}));
        end
    end
    rejected = false;
    try
        bds_paper_options(1, 'external', 'noacc');
    catch exception
        assert(strcmp(exception.identifier, 'bds_paper_options:UnknownConfiguration'));
        rejected = true;
    end
    assert(rejected);
    fprintf('PAPER_OPTIONS_RELOCATION_OK configurations=12 solver_pairs=12 invalid=1\n');
else
    assert(strcmp(stage, 'regression'));
    addpath(fullfile(root, 'tests'));
    run_bds_regression_suite();
end
fprintf('RELOCATION_STAGE_OK %s\n', stage);
end

function result = run_solver(x0, options)
options.output_xhist = true;
options.output_alpha_hist = true;
options.output_block_hist = true;
options.output_grad_hist = true;
rng(options.seed, 'twister');
[result.x, result.f, result.exitflag, result.output] = bds(@(x) sum((x - 0.27).^2), x0, options);
end
